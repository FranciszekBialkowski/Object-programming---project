package extra;

public interface IItem {

    void upgrade();
}
